1.variable
2.assignment
3..comparision operator
4.conditional statement
5.for()
6.create func , we called
IN this exapmple lets understsnd how to create functions