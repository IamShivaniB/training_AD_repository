//Js Function -> function <function_name>([<parameters>...]){}
//Create addtion(n1,n2)=> n1+n2
//addition function will print the addition value
function addition(n1,n2){
    let result=n1+n2;
    console.log(n1+"+"+n2+"= "+result)
}
function subtraction(n1,n2){
    const result=n1-n2;
    console.log(n1+"+"+n2+"= "+result);
}

addition(10,20);
subtraction(10,20);