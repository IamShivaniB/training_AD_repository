export default class Product{
    constructor(pid,pname,unit_price){
        this.pid=pid;
        this.panem=pname;
        this.unit_price=unit_price;
    }
}
