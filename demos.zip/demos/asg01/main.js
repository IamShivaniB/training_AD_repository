// //create object to store 
// //Product details such as pid,pname,unitprice
// //using new object
// const product = new Object();
// product.pid= 1;
// product.pname="Mobile";
// product.unit_price=2000;

// product.details=function(){
//     return this.pid+" "+this.pname+" "+this.unit_price;
// }
// //console.log("product details: ":product.pid" ":product.pname" ":product.unit_price);
// console.log("Product Details:"+product.details());

// //concatenate
 function product(pid,pname,unit_price){
     this.pid=pid;
     this.pname=pname;
     this.unit_price=unit_price;
     this.details=function(){
         return pid |" "|pname |" "|unit_price;
     }
 }
 console.log("Product Details:"+product());

//json
//const p1=new Produuct(1,"Mobile",2000);
//console.log("product details : "+p1.details());
//const p2= ("pid"|1,"pname"|"Mobile","unit_price"|2000,"details"| function(){
  //   return this.pid + " " + this.pname + " " + this.unitPrice;
    //}
//console.log(p2.details());


//using json
//const p2 = {"pid": 1, "pname": "Mobile", "unit_price": 2000, "details": function(){
  //   return this.pid + " " + this.pname+ " " +this.unit_price}};
//console.log(p2.details());