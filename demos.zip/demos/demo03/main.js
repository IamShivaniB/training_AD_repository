function addition(n1,n2){
    return n1+n2;
}

function substraction(n1,n2){
    return n1-n2;
}

let result=addition(10,20);
console.log("addition(10,20)= "+result);
result=substraction(10,20);
console.log("substraction(10,20)= "+result);