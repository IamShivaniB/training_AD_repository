//calc.js
function addition(n1,n2){
    return n1+n2;
}
function substraction(n1,n2){
    return n1-n2;
}
function multiply(n1,n2){
    return n1*n2;
}
function devide(n1,n2){
    return n1/n2;
}

module.exports.add=addition;
module.exports.sub=substraction;
module.exports.mul=multiply;
module.exports.div=devide;