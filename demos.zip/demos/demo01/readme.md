This explains the Javascript basic demo
create main.js
2. excecute it using node
console.log()=> console is an object which has log() method log() methods accepts string values in '' or "" Data type in Javascript called String : '', "", " ' ", '""' String + String is string concatenation

<!-- Create variable in js -->
<variable_name>=<assign_value> *JavaScript is Not a TypeSafe lanaguage What is TypeSAfe? when we decare a variable along with the declaration we indicate the type of data empno emp.empno%type; or empno numeric;