import express from 'express';
import path from 'path';
import library from './app/app-route-lib.js';
import society from './app/app-route-soc.js';
import showroom from './app/app-route_show.js';

const server = express();
const port = 3000;
server.use(express.urlencoded({ extended: true }));
server.use(express.json());
const __dirname = path.resolve(path.dirname(""));


server.get('/', (req, resp) => {
    resp.setHeader('Content-Type', "text/html");
    resp.sendFile(__dirname + "/index.html");
});


server.use('/library', library)
server.use('/society', society)
server.use('/showroom', showroom)


server.listen(port, () => { console.log("http://localhost:3000"); })