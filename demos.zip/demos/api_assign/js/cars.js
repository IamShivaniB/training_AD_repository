class Cars{
    constructor(carid, carName, carModel, carPrice){
        this.carid = carid;
        this.carName = carName;
        this.carModel = carModel;
        this.carPrice = carPrice;
    }
}

export default Cars;