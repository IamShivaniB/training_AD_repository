 class Persons{
     constructor(pid, firstName, lastName, age, gender){
         this.pid = pid;
         this.firstName = firstName;
         this.lastName = lastName;
         this.age = age;
         this.gender = gender;
     }
 }

 export default Persons