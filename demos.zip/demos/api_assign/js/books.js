class Books{
    constructor(bookid, bookname, authorname, unitprice){
        this.bookid = bookid;
        this.bookname = bookname;
        this.authorname = authorname;
        this.unitprice = unitprice;
    }
}


export default Books