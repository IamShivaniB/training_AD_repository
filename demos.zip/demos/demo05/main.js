//main.js 
//anonymous function
//Anonymous function : function without name
// we have created  a variable referencing to a function
// in below code app is a function variable
const app=function (){
    console.log("Function without name is called");
}

app();