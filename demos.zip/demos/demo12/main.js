const calc=require('./calc');
console.log("add= "+calc.add(10,20));
console.log("sub= "+calc.sub(10,20));
console.log("mul= "+calc.mul(10,20));
console.log("div= "+calc.div(10,20));

